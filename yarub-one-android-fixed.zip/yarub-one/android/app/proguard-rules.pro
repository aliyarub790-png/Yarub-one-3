# WebView JavaScript interfaces would need keep rules; none are used, because
# exposing native methods to page JavaScript is not something this app does.
-keepattributes SourceFile,LineNumberTable
